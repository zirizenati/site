# Trading Dashboard
Simple BTC/USD chart with live news. Built using React + Tailwind. Deployed on Vercel.

Replace `YOUR_API_KEY` with your key from https://gnews.io
